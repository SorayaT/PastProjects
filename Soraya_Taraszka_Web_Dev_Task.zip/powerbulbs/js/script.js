
$(document).ready(function() {

    $('input,date').focus(function(){
       $(this).removeAttr('placeholder');
    });

    $('input,date').focusout(function(){
       $(this).text('placeholder');
    });

	$("#submit_registration").unbind('click').click(function(){

		var fname = document.forms["registration_form"]["firstName"];
		var lname = document.forms["registration_form"]["lastName"];
		var address = document.forms["registration_form"]["adress"];
		var country = document.forms["registration_form"]["country"];
		var postcode = document.forms["registration_form"]["postcode"];
		var email = document.forms["registration_form"]["email"];
		var tel = document.forms["registration_form"]["tel"];
		var dob = document.forms["registration_form"]["dob"];


		var pass= document.forms["registration_form"]["pass"]	;
		var passrepeat= document.forms["registration_form"]["passrepeat"];
		var validation = 0;

	//name field
		if (/[^a-zA-Z0-9\-\/]/.test(fname.value) ){
			validation ++;
			$("#name_spec").show();
		}else{
			$("#name_spec").hide();
		}

		if (fname.value.length == 0) {
			validation ++;
			$("#name_empty").show();
			// alert("empty");
		}else{
			$("#name_empty").hide();
		}

	// Last name field

		if (/[^a-zA-Z0-9\-\/]/.test(lname.value)) {
			validation ++;
			$("#lname_spec").show();
		}else{
			$("#lname_spec").hide();
		}

		if (lname.value.length == 0) {
			validation ++;
			$("#lname_empty").show();
		}else{
			$("#lname_empty").hide();
		}
	//address field

		if (/[^a-zA-Z0-9\-\/]+$/.test(address.value)) { 
			validation ++;
			$("#address_spec").show();
			// alert("Address has special characters");
		}else{
			$("#address_spec").hide();
		}

		if (address.value.length == 0) {
			validation ++;
			$("#address_empty").show();
		}else{
			$("#address_empty").hide();
		}

	//country field

		if (/[^a-zA-Z0-9\-\/]+$/.test(country.value)) {
			validation ++;
			$("#country_spec").show();
		}else{
			$("#country_spec").hide();
		}

		if (country.value.length == 0) {
			validation ++;
			$("#country_empty").show();
		}else{
			$("#country_empty").hide();
		}

	// post code field
		if (/[^a-zA-Z0-9\-\/]+$/.test(postcode.value)) {
			validation ++;
			$("#postcode_spec").show();
		}else{
			$("#postcode_spec").hide();
		}

		if (postcode.value.length == 0) {
			validation ++;
			$("#postcode_empty").show();
		}else{
			$("#postcode_empty").hide();
		}

	// Telephone field
		if (/[^a-zA-Z0-9\-\/]/.test(tel.value) || /[A-Z]/.test(tel.value) || /[a-z]/.test(tel.value)) {
			validation ++;
			$("#tel_num").show();
		}else{
			$("#tel_num").hide();
		}

	// Email code field




		if (email.value.length == 0) {
			validation ++;
			$("#email_empty").show();
		}else{
			$("#email_empty").hide();
		}

	//password fields

		if(pass.value != passrepeat.value){
			validation ++;
			$(".password_message").show();
		}else{
			if (pass.value.length < 6 || pass.value.length > 15) {
				validation ++;
				$(".password_message").show();
			}else{
				if(!/[A-Z]/.test(pass.value) || !/[a-z]/.test(pass.value) || !/[0-9]/.test(pass.value)) {
					validation ++;
					$(".password_message").show();
				}else{
					$(".password_message").hide();
				}
			}
		}

	// validation results

		console.log("val is" + validation);

		if(validation == 0){
			// alert("reg success");
			// window.location.href = 'congratulations.html';
			$( "#registration_form" ).remove();
			$("#registration_details").show();

			$("#registration_details").append("Thank you for registering! Here are your details: <br><br> Name: "
				+ fname.value+"<br> Surname: "+ lname.value
				+ "<br> Address: "+ address.value
				+ "<br> Country: "+ country.value
				+ "<br> Postcode: "+ postcode.value
				+ "<br> Telephone Number: "+tel.value
				+ "<br> DOB: "+ dob.value
				+ "<br> Email: "+ email.value
				+ "<br> Password: "+ pass.value
				);
		}
				  return false;

	});
	
	// }
});