$(".link").click(function(){
	    var id = this.id;
	    $('html, body').animate({
        scrollTop: $("#"+id+"page").offset().top
     }, 1000);
});

// $(".page").isvisible(function(){
// 	    alert(this.id);
// });